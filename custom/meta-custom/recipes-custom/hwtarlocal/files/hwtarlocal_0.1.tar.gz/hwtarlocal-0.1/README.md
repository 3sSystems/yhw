# yocto-test-apps

This is the git repo that holds the resources referred to in the blog posts about Yocto on https://kickstartembedded.com ... check out this blog now!
