#include <stdio.h>

int main(void) {
	printf("Hello, World from an application cloned from Github!\r\n");
	return 0;
}
